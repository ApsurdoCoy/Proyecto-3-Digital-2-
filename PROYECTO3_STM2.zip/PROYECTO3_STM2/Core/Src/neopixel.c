/**
 ******************************************************************************
 * @file    neopixel.c
 * @brief   Driver WS2812B (NeoPixel) con TIM3_CH1 (PWM) + DMA
 *          Proyecto 3 - Centro de Control para Parqueo (IE3054)
 ******************************************************************************
 * Cada bit del WS2812B dura 1.25 us (800 kHz = un periodo del PWM).
 *   bit 1 -> ~0.8 us en alto  (CCR = 64 de 100)
 *   bit 0 -> ~0.4 us en alto  (CCR = 32 de 100)
 * El DMA carga un valor de CCR por periodo; al final se mandan periodos en 0
 * (> 280 us en bajo) para que los LEDs "latcheen" los colores.
 * Orden de color del WS2812B: G, R, B (MSB primero).
 ******************************************************************************
 */
#include "neopixel.h"
#include "main.h"

extern TIM_HandleTypeDef htim3;          /* definido por CubeMX (main.c o tim.c) */

#define NP_BIT1        64
#define NP_BIT0        32
#define NP_RESET_SLOTS 240                 /* 240 x 1.25 us = 300 us en bajo */
#define NP_BUF_LEN     (NP_NUM_LEDS * 24 + NP_RESET_SLOTS)

static uint8_t           color[NP_NUM_LEDS][3];   /* G, R, B por LED          */
static uint16_t          npBuf[NP_BUF_LEN];       /* valores de CCR para DMA  */
static volatile uint8_t  npOcupado = 0;           /* 1 mientras transmite     */

uint8_t NeoPixel_DmaListo(void)
{
    return htim3.hdma[TIM_DMA_ID_CC1] != NULL;
}

void NeoPixel_Init(void)
{
    /* Seguridad: el DMA debe ir de memoria (buffer) hacia el registro CCR1.
     * Si en CubeMX quedo como Peripheral To Memory, se corrige aqui.       */
    DMA_HandleTypeDef *hdma = htim3.hdma[TIM_DMA_ID_CC1];
    if (hdma != NULL && hdma->Init.Direction != DMA_MEMORY_TO_PERIPH) {
        HAL_DMA_DeInit(hdma);
        hdma->Init.Direction = DMA_MEMORY_TO_PERIPH;
        HAL_DMA_Init(hdma);
    }

    for (uint8_t i = 0; i < NP_NUM_LEDS; i++)
        NeoPixel_Set(i, 0, 0, 0);
    NeoPixel_Show();
}

void NeoPixel_Set(uint8_t led, uint8_t r, uint8_t g, uint8_t b)
{
    if (led >= NP_NUM_LEDS) return;
    color[led][0] = g;
    color[led][1] = r;
    color[led][2] = b;
}

void NeoPixel_Parqueo(uint8_t led, uint8_t ocupado)
{
    if (ocupado) NeoPixel_Set(led, NP_BRILLO, 0, 0);   /* rojo  */
    else         NeoPixel_Set(led, 0, NP_BRILLO, 0);   /* verde */
}

void NeoPixel_Show(void)
{
    /* Sin DMA configurado en CubeMX no se puede transmitir */
    if (!NeoPixel_DmaListo()) return;

    /* Espera a que termine una transmision anterior (dura ~0.4 ms) */
    uint32_t t0 = HAL_GetTick();
    while (npOcupado && (HAL_GetTick() - t0) < 5) { }

    /* Arma el buffer: 24 bits por LED + periodos de reset en 0 */
    uint32_t k = 0;
    for (uint8_t i = 0; i < NP_NUM_LEDS; i++)
        for (uint8_t c = 0; c < 3; c++)
            for (int8_t b = 7; b >= 0; b--)
                npBuf[k++] = (color[i][c] & (1u << b)) ? NP_BIT1 : NP_BIT0;
    while (k < NP_BUF_LEN)
        npBuf[k++] = 0;

    npOcupado = 1;
    if (HAL_TIM_PWM_Start_DMA(&htim3, TIM_CHANNEL_1, (uint32_t *)npBuf, NP_BUF_LEN) != HAL_OK)
        npOcupado = 0;
}

/* Fin de la transferencia DMA: se detiene el PWM (la linea queda en bajo) */
void HAL_TIM_PWM_PulseFinishedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM3) {
        HAL_TIM_PWM_Stop_DMA(htim, TIM_CHANNEL_1);
        npOcupado = 0;
    }
}
