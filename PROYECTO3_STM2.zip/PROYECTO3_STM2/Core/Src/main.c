/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include "display7seg.h"
#include "neopixel.h"
#include "i2c_esclavo.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define NUM_SENSORES          4    /* P5..P8 en esta Nucleo                      */
#define PERIODO_MUESTREO_MS   10   /* lectura de sensores cada 10 ms             */
#define MUESTRAS_ESTABLES     3    /* 3 lecturas iguales = 30 ms de antirrebote  */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/

/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* ----------------------- Sensores IR de obstaculos ------------------------ */
/* Salida OUT: 0 = carro detectado (ocupado), 1 = espacio libre
 * Indice 0..3 = parqueos P5..P8                                              */
static GPIO_TypeDef * const sensPort[NUM_SENSORES] = {
    SENS5_GPIO_Port, SENS6_GPIO_Port, SENS7_GPIO_Port, SENS8_GPIO_Port
};
static const uint16_t sensPin[NUM_SENSORES] = {
    SENS5_Pin, SENS6_Pin, SENS7_Pin, SENS8_Pin
};

static uint8_t sensEstable[NUM_SENSORES];    /* lectura sin rebote             */
static uint8_t sensContador[NUM_SENSORES];   /* muestras iguales consecutivas  */

/* ------------------------------ Estado parqueo ---------------------------- */
/* bit i = 1 -> P(i+5) ocupado. Esta mascara se enviara por I2C al ESP32      */
static volatile uint8_t mascaraFila = 0xFF;  /* 0xFF fuerza la 1a actualizacion */

/* Libres de la otra fila (P1..P4): llega por I2C desde el ESP32.
 * Mientras el ESP32 no envia datos vale 0 (el display muestra solo esta fila) */
static volatile uint8_t libresOtraFila = 0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
static void    Sensores_Init(void);
static uint8_t Sensores_Leer(void);
static uint8_t ContarLibres(uint8_t mascara);
static void    Indicadores_Actualizar(uint8_t mascara);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_I2C1_Init();
  MX_TIM3_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
  printf("\r\nProyecto 3 - Parqueo-matic (Nucleo 2: P5..P8)\r\n");

  Display_Apagar();
  NeoPixel_Init();            /* todos apagados                            */
  if (!NeoPixel_DmaListo())
    printf("AVISO: falta configurar el DMA de TIM3_CH1 en CubeMX\r\n");

  Sensores_Init();
  I2C_Esclavo_Init(&hi2c1, 0x21);  /* esclavo I2C del ESP32 (direccion 0x21) */
  uint32_t tMuestreo = HAL_GetTick();
  /* USER CODE END 2 */

  /* Initialize leds */
  BSP_LED_Init(LED2);

  /* Initialize USER push-button, will be used to trigger an interrupt each time it's pressed.*/
  BSP_PB_Init(BUTTON_USER, BUTTON_MODE_EXTI);

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

    /* ---- 1. Lectura de sensores cada PERIODO_MUESTREO_MS ---- */
    if (HAL_GetTick() - tMuestreo >= PERIODO_MUESTREO_MS) {
      tMuestreo = HAL_GetTick();

      uint8_t nueva = Sensores_Leer();

      /* ---- 2. I2C: dato que leera el ESP32 + estado de la otra fila ---- */
      I2C_Esclavo_SetFila(nueva);
      uint8_t libresOtra = 0;
      if (I2C_Esclavo_Recibido())                     /* P1..P4 = bits 0..3 */
        libresOtra = ContarLibres(I2C_Esclavo_Estado() & 0x0F);

      /* ---- 3. Si hubo cambio: NeoPixels + display + reporte ---- */
      if (nueva != mascaraFila || libresOtra != libresOtraFila) {
        mascaraFila    = nueva;
        libresOtraFila = libresOtra;
        Indicadores_Actualizar(nueva);
        printf("Fila 2 ocupados: 0x%X  Libres fila: %u  Total libres: %u\r\n",
               nueva, ContarLibres(nueva), ContarLibres(nueva) + libresOtraFila);
      }
    }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 80;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* ============================ Sensores ==================================== */
static void Sensores_Init(void)
{
  for (uint8_t i = 0; i < NUM_SENSORES; i++) {
    sensEstable[i]  = HAL_GPIO_ReadPin(sensPort[i], sensPin[i]);
    sensContador[i] = 0;
  }
}

/**
  * @brief  Lee los 4 sensores con filtro antirrebote.
  * @retval Mascara de ocupados (bit0 = P5 ... bit3 = P8)
  */
static uint8_t Sensores_Leer(void)
{
  uint8_t mascara = 0;
  for (uint8_t i = 0; i < NUM_SENSORES; i++) {
    uint8_t lectura = HAL_GPIO_ReadPin(sensPort[i], sensPin[i]);

    if (lectura != sensEstable[i]) {
      if (++sensContador[i] >= MUESTRAS_ESTABLES) {
        sensEstable[i]  = lectura;
        sensContador[i] = 0;
      }
    } else {
      sensContador[i] = 0;
    }

    if (sensEstable[i] == GPIO_PIN_RESET)    /* 0 = carro detectado */
      mascara |= (1u << i);
  }
  return mascara;
}

static uint8_t ContarLibres(uint8_t mascara)
{
  uint8_t libres = 0;
  for (uint8_t i = 0; i < NUM_SENSORES; i++)
    if (!(mascara & (1u << i))) libres++;
  return libres;
}

/* ========================== Indicadores =================================== */
/**
  * @brief  NeoPixel de cada espacio (rojo/verde) y total de libres en el
  *         display de 7 segmentos.
  */
static void Indicadores_Actualizar(uint8_t mascara)
{
  for (uint8_t i = 0; i < NUM_SENSORES; i++)
    NeoPixel_Parqueo(i, (mascara >> i) & 1u);
  NeoPixel_Show();

  Display_Mostrar(ContarLibres(mascara) + libresOtraFila);
}

/* ===================== printf por USART2 (ST-Link VCP) ==================== */
int __io_putchar(int ch)
{
  HAL_UART_Transmit(&huart2, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
  return ch;
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
