/**
 ******************************************************************************
 * @file    display7seg.c
 * @brief   Display de 7 segmentos (1 digito) - parqueos disponibles (0..8)
 *          Proyecto 3 - Centro de Control para Parqueo (IE3054) - Nucleo 2
 ******************************************************************************
 */
#include "display7seg.h"
#include "main.h"

/* Segmentos en orden a, b, c, d, e, f, g */
static GPIO_TypeDef * const segPort[7] = {
    SEG_A_GPIO_Port, SEG_B_GPIO_Port, SEG_C_GPIO_Port, SEG_D_GPIO_Port,
    SEG_E_GPIO_Port, SEG_F_GPIO_Port, SEG_G_GPIO_Port
};
static const uint16_t segPin[7] = {
    SEG_A_Pin, SEG_B_Pin, SEG_C_Pin, SEG_D_Pin,
    SEG_E_Pin, SEG_F_Pin, SEG_G_Pin
};

/* Patrones de los digitos 0..9 (bit0 = a ... bit6 = g, 1 = encendido) */
static const uint8_t digitos[10] = {
    0x3F, /* 0 */  0x06, /* 1 */  0x5B, /* 2 */  0x4F, /* 3 */  0x66, /* 4 */
    0x6D, /* 5 */  0x7D, /* 6 */  0x07, /* 7 */  0x7F, /* 8 */  0x6F  /* 9 */
};

/* Nivel del pin para encender / apagar un segmento segun el tipo de display */
#define SEG_ON   (DISPLAY_ANODO_COMUN ? GPIO_PIN_RESET : GPIO_PIN_SET)
#define SEG_OFF  (DISPLAY_ANODO_COMUN ? GPIO_PIN_SET   : GPIO_PIN_RESET)

static void Display_Patron(uint8_t patron)
{
    for (uint8_t s = 0; s < 7; s++)
        HAL_GPIO_WritePin(segPort[s], segPin[s], (patron & (1u << s)) ? SEG_ON : SEG_OFF);
}

void Display_Mostrar(uint8_t numero)
{
    Display_Patron(digitos[numero % 10]);
}

void Display_Apagar(void)
{
    Display_Patron(0x00);
    Display_Punto(0);
}

void Display_Punto(uint8_t encendido)
{
    HAL_GPIO_WritePin(SEG_DP_GPIO_Port, SEG_DP_Pin, encendido ? SEG_ON : SEG_OFF);
}
