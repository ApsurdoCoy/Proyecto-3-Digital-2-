/**
 ******************************************************************************
 * @file    i2c_esclavo.c
 * @brief   Nucleo como ESCLAVO I2C del ESP32 (modo Listen por interrupciones)
 *          Proyecto 3 - Centro de Control para Parqueo (IE3054)
 ******************************************************************************
 * Funcionamiento (todo por interrupciones, no bloquea el programa principal):
 *   1. HAL_I2C_EnableListen_IT(): la Nucleo espera a que el maestro la llame.
 *   2. Cuando el ESP32 envia la direccion de esta Nucleo -> HAL_I2C_AddrCallback
 *        - si el maestro quiere LEER    -> se le transmite txFila (1 byte)
 *        - si el maestro quiere ESCRIBIR -> se recibe 1 byte en rxBuf
 *   3. Al terminar la transferencia se vuelve a escuchar (ListenCplt / Error).
 ******************************************************************************
 */
#include "i2c_esclavo.h"

#ifdef HAL_I2C_MODULE_ENABLED

static I2C_HandleTypeDef *hI2C = NULL;

static volatile uint8_t txFila    = 0;   /* fila de esta Nucleo (para el ESP32)  */
static uint8_t          txBuf     = 0;   /* copia que se transmite                */
static uint8_t          rxBuf     = 0;   /* byte que llega del ESP32              */
static volatile uint8_t estado    = 0;   /* ultimo estado completo recibido       */
static volatile uint8_t recibido  = 0;   /* 1 cuando ya llego al menos un dato    */

/* ============================ Funciones publicas ========================== */
void I2C_Esclavo_Init(I2C_HandleTypeDef *hi2c, uint8_t direccion)
{
    hI2C = hi2c;

    /* La HAL usa la direccion desplazada 1 bit (0x20 -> 0x40). Si en CubeMX
     * quedo otra direccion, se corrige y se reinicializa el periferico.    */
    if (hI2C->Init.OwnAddress1 != ((uint32_t)direccion << 1)) {
        HAL_I2C_DeInit(hI2C);
        hI2C->Init.OwnAddress1 = (uint32_t)direccion << 1;
        HAL_I2C_Init(hI2C);
    }
    HAL_I2C_EnableListen_IT(hI2C);
}

void I2C_Esclavo_SetFila(uint8_t fila)
{
    txFila = fila & 0x0F;
}

uint8_t I2C_Esclavo_Estado(void)
{
    return estado;
}

uint8_t I2C_Esclavo_Recibido(void)
{
    return recibido;
}

/* ========================= Callbacks de la HAL ============================ */
/* El maestro envio nuestra direccion */
void HAL_I2C_AddrCallback(I2C_HandleTypeDef *hi2c, uint8_t TransferDirection,
                          uint16_t AddrMatchCode)
{
    (void)AddrMatchCode;
    if (hi2c != hI2C) return;

    if (TransferDirection == I2C_DIRECTION_TRANSMIT) {
        /* El maestro ESCRIBE -> recibimos el estado completo */
        HAL_I2C_Slave_Seq_Receive_IT(hi2c, &rxBuf, 1, I2C_FIRST_AND_LAST_FRAME);
    } else {
        /* El maestro LEE -> enviamos nuestra fila */
        txBuf = txFila;
        HAL_I2C_Slave_Seq_Transmit_IT(hi2c, &txBuf, 1, I2C_FIRST_AND_LAST_FRAME);
    }
}

/* Llego el byte del maestro */
void HAL_I2C_SlaveRxCpltCallback(I2C_HandleTypeDef *hi2c)
{
    if (hi2c != hI2C) return;
    estado   = rxBuf;
    recibido = 1;
}

/* Termino la transaccion: volver a escuchar */
void HAL_I2C_ListenCpltCallback(I2C_HandleTypeDef *hi2c)
{
    if (hi2c != hI2C) return;
    HAL_I2C_EnableListen_IT(hi2c);
}

/* Error (p. ej. el NACK normal del maestro al final de una lectura) */
void HAL_I2C_ErrorCallback(I2C_HandleTypeDef *hi2c)
{
    if (hi2c != hI2C) return;
    HAL_I2C_EnableListen_IT(hi2c);
}

#endif /* HAL_I2C_MODULE_ENABLED */
