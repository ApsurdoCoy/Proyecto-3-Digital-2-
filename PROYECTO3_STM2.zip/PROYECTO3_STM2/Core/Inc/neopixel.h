/**
 ******************************************************************************
 * @file    neopixel.h
 * @brief   Driver WS2812B (NeoPixel) con TIM3_CH1 (PWM) + DMA
 *          Proyecto 3 - Centro de Control para Parqueo (IE3054)
 ******************************************************************************
 * Requisitos en CubeMX:
 *   - TIM3 CH1 en PWM, Prescaler = 0, Period = 99 (timer a 80 MHz -> 800 kHz)
 *   - DMA: TIM3_CH1/TRIG, Memory To Peripheral, Normal, Half Word / Half Word
 * Los LEDs van en cadena: DIN del LED 0 <- pin del timer, DO -> DIN siguiente.
 ******************************************************************************
 */
#ifndef INC_NEOPIXEL_H_
#define INC_NEOPIXEL_H_

#include <stdint.h>

#define NP_NUM_LEDS   4     /* LEDs en la cadena (un parqueo cada uno)        */
#define NP_BRILLO     40    /* 0..255 - brillo maximo de cada color           */

void    NeoPixel_Init(void);
void    NeoPixel_Set(uint8_t led, uint8_t r, uint8_t g, uint8_t b);
void    NeoPixel_Show(void);                      /* envia los colores        */
void    NeoPixel_Parqueo(uint8_t led, uint8_t ocupado);   /* rojo / verde     */
uint8_t NeoPixel_DmaListo(void);                  /* 1 si hay DMA configurado */

#endif /* INC_NEOPIXEL_H_ */
