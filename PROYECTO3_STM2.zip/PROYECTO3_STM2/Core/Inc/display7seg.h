/**
 ******************************************************************************
 * @file    display7seg.h
 * @brief   Display de 7 segmentos (1 digito) - parqueos disponibles (0..8)
 *          Proyecto 3 - Centro de Control para Parqueo (IE3054) - Nucleo 2
 ******************************************************************************
 * Pines (CubeMX, ver main.h):
 *   a=PA10(D2) b=PB3(D3) c=PB5(D4) d=PB4(D5) e=PB10(D6) f=PA8(D7) g=PA9(D8)
 *   dp=PC7(D9)
 ******************************************************************************
 */
#ifndef INC_DISPLAY7SEG_H_
#define INC_DISPLAY7SEG_H_

#include <stdint.h>

/* 0 = catodo comun (COM a GND)   1 = anodo comun (COM a 3V3) */
#define DISPLAY_ANODO_COMUN   0

void Display_Mostrar(uint8_t numero);   /* muestra 0..9                */
void Display_Apagar(void);              /* apaga todos los segmentos   */
void Display_Punto(uint8_t encendido);  /* punto decimal (dp)          */

#endif /* INC_DISPLAY7SEG_H_ */
