/**
 ******************************************************************************
 *          Proyecto 3 - Centro de Control para Parqueo (IE3054)
 */
#include "parqueo_gui.h"
#include "ili9341.h"

/* ============================== Geometria ================================= */
#define AREA_X      8                       /* esquina del area de parqueo  */
#define AREA_Y      28
#define SLOT_W      54                      /* ancho de cada espacio        */
#define SLOT_H      78                      /* alto de cada espacio         */
#define LANE_H      48                      /* alto del carril central      */
#define AREA_W      (4 * SLOT_W)
#define AREA_H      (2 * SLOT_H + LANE_H)
#define ROW1_Y      AREA_Y
#define LANE_Y      (AREA_Y + SLOT_H)
#define ROW2_Y      (LANE_Y + LANE_H)

#define LINE_W      3                       /* lineas amarillas divisoras   */

#define CAR_W       32
#define CAR_H       56

#define PANEL_X     234                     /* panel de disponibles         */
#define PANEL_Y     AREA_Y
#define PANEL_W     80
#define PANEL_H     AREA_H

#define NUM_ESCALA  5                       /* numero grande: 16x16 * 5     */
#define NUM_TAM     (16 * NUM_ESCALA)
#define NUM_X       PANEL_X
#define NUM_Y       (PANEL_Y + 62)

/* Fuentes de la libreria (font.c) */
#define FONT_S_W    8                       /* fontSize 1: 8 x 12  */
#define FONT_B_W    16                      /* fontSize 2: 16 x 16 */
extern const uint16_t bigFont[1520];

/*Colores*/
#define RGB565(r,g,b)  ((uint16_t)((((r) & 0xF8) << 8) | (((g) & 0xFC) << 3) | ((b) >> 3)))

#define COL_BG       RGB565(236, 239, 242)
#define COL_FRAME    RGB565(170, 30, 30)
#define COL_SLOT     RGB565(200, 205, 205)
#define COL_LANE     RGB565(70, 72, 78)
#define COL_LINE     RGB565(245, 190, 40)
#define COL_WINDOW   RGB565(40, 50, 70)
#define COL_TIRE     RGB565(25, 25, 25)
#define COL_LIGHT    RGB565(255, 240, 150)
#define COL_PANEL    RGB565(250, 252, 255)
#define COL_PANEL_B  RGB565(110, 160, 220)
#define COL_TEXT     RGB565(30, 35, 45)
#define COL_WHITE    0xFFFF
#define COL_LIBRE    RGB565(40, 200, 70)
#define COL_OCUPADO  RGB565(230, 40, 40)
#define COL_LIBRE_TX RGB565(40, 150, 60)

/* Color de cada carro (P1..P8), parecido a la imagen de referencia */
static const uint16_t carColor[NUM_PARQUEOS] = {
    RGB565(140,  90,  60),  /* cafe        */
    RGB565( 90, 140,  80),  /* verde       */
    RGB565(185, 180,  80),  /* olivo       */
    RGB565(235, 105,  60),  /* naranja     */
    RGB565(235, 105,  60),  /* naranja     */
    RGB565( 80,  95, 160),  /* azul        */
    RGB565( 90, 140,  80),  /* verde       */
    RGB565(200,  50,  60)   /* rojo        */
};

static uint8_t estadoActual = 0x00;   /* mascara mostrada en pantalla */
static uint8_t libresActual = 0xFF;   /* fuerza el primer dibujo      */

/* Figuras construidas con FillRect*/

static void Rellenar(int x, int y, int w, int h, uint16_t c)
{
    if (w > 0 && h > 0) FillRect(x, y, w, h, c);
}

/* Mitad del ancho de un circulo de radio r a una distancia dy del centro */
static int AnchoCirculo(int r, int dy)
{
    int dx = 0;
    while ((dx + 1) * (dx + 1) + dy * dy <= r * r) dx++;
    return dx;
}

static void Circulo(int cx, int cy, int r, uint16_t c)
{
    for (int dy = -r; dy <= r; dy++) {
        int dx = AnchoCirculo(r, dy);
        Rellenar(cx - dx, cy + dy, 2 * dx + 1, 1, c);
    }
}

static void RectRedondo(int x, int y, int w, int h, int r, uint16_t c)
{
    if (r > w / 2) r = w / 2;
    if (r > h / 2) r = h / 2;
    Rellenar(x, y + r, w, h - 2 * r, c);            /* parte central */
    for (int i = 0; i < r; i++) {                   /* esquinas      */
        int inset = r - AnchoCirculo(r, r - i);
        Rellenar(x + inset, y + i,         w - 2 * inset, 1, c);
        Rellenar(x + inset, y + h - 1 - i, w - 2 * inset, 1, c);
    }
}

static void Texto(int x, int y, const char *s, int size, uint16_t fg, uint16_t bg)
{
    LCD_Print((char *)s, x, y, size, fg, bg);
}

/* Caracter de bigFont (16x16) escalado; dibuja por tramos horizontales */
static void CaracterGrande(int x, int y, char ch, int escala, uint16_t fg, uint16_t bg)
{
    Rellenar(x, y, 16 * escala, 16 * escala, bg);
    const uint16_t *g = &bigFont[(ch - 32) * 16];

    for (int fila = 0; fila < 16; fila++) {
        int col = 0;
        while (col < 16) {
            if (g[fila] & (1u << (15 - col))) {
                int inicio = col;
                while (col < 16 && (g[fila] & (1u << (15 - col)))) col++;
                Rellenar(x + inicio * escala, y + fila * escala,
                         (col - inicio) * escala, escala, fg);
            } else {
                col++;
            }
        }
    }
}

/* ============================ Elementos GUI =============================== */

static uint16_t Oscurecer(uint16_t c) { return (c >> 1) & 0x7BEF; }

static int SlotX(uint8_t i) { return AREA_X + (i % 4) * SLOT_W; }
static int SlotY(uint8_t i) { return (i < 4) ? ROW1_Y : ROW2_Y; }

/* Carro visto desde arriba. frenteAbajo = 1 si el frente mira hacia abajo */
static void DibujarCarro(int x, int y, uint16_t color, uint8_t frenteAbajo)
{
    /* Llantas */
    Rellenar(x - 2,         y + 8,          4, 11, COL_TIRE);
    Rellenar(x + CAR_W - 2, y + 8,          4, 11, COL_TIRE);
    Rellenar(x - 2,         y + CAR_H - 19, 4, 11, COL_TIRE);
    Rellenar(x + CAR_W - 2, y + CAR_H - 19, 4, 11, COL_TIRE);

    /* Carroceria y techo */
    RectRedondo(x, y, CAR_W, CAR_H, 9, color);
    RectRedondo(x + 6, y + 18, CAR_W - 12, 22, 4, Oscurecer(color));

    if (frenteAbajo) {
        RectRedondo(x + 5, y + 40, CAR_W - 10, 8, 3, COL_WINDOW);   /* parabrisas */
        RectRedondo(x + 7, y + 10, CAR_W - 14, 6, 2, COL_WINDOW);   /* trasera    */
        Rellenar(x + 5,          y + CAR_H - 3, 6, 2, COL_LIGHT);   /* luces      */
        Rellenar(x + CAR_W - 11, y + CAR_H - 3, 6, 2, COL_LIGHT);
    } else {
        RectRedondo(x + 5, y + 8,  CAR_W - 10, 8, 3, COL_WINDOW);
        RectRedondo(x + 7, y + 40, CAR_W - 14, 6, 2, COL_WINDOW);
        Rellenar(x + 5,          y + 1, 6, 2, COL_LIGHT);
        Rellenar(x + CAR_W - 11, y + 1, 6, 2, COL_LIGHT);
    }
}

/* Interior de un espacio (libre u ocupado) */
static void DibujarEspacio(uint8_t i, uint8_t ocupado)
{
    int x = SlotX(i) + LINE_W;
    int y = SlotY(i);
    int w = SLOT_W - LINE_W;
    uint8_t filaArriba = (i < 4);

    Rellenar(x, y, w, SLOT_H, COL_SLOT);

    /* Topes amarillos del lado del carril */
    int yTope = filaArriba ? (y + SLOT_H - 7) : (y + 3);
    Rellenar(x + 6,          yTope, 15, 4, COL_LINE);
    Rellenar(x + w - 6 - 15, yTope, 15, 4, COL_LINE);

    if (ocupado) {
        int cx = x + (w - CAR_W) / 2;
        int cy = filaArriba ? (y + 6) : (y + SLOT_H - 6 - CAR_H);
        DibujarCarro(cx, cy, carColor[i], filaArriba);
    } else {
        int tx = x + (w - 5 * FONT_S_W) / 2;
        int ty = filaArriba ? (y + 28) : (y + SLOT_H - 40);
        Texto(tx, ty, "LIBRE", 1, COL_LIBRE_TX, COL_SLOT);
    }
}

/* Indicador en el carril (verde libre / rojo ocupado), como el NeoPixel */
static void DibujarIndicador(uint8_t i, uint8_t ocupado)
{
    int cx = SlotX(i) + SLOT_W / 2 - 9;
    int cy = (i < 4) ? (LANE_Y + 12) : (LANE_Y + LANE_H - 12);
    Circulo(cx, cy, 8, COL_WHITE);
    Circulo(cx, cy, 6, ocupado ? COL_OCUPADO : COL_LIBRE);
}

/* Numero grande con la cantidad de espacios libres */
static void DibujarDisponibles(uint8_t libres)
{
    uint16_t color = (libres > 0) ? COL_LIBRE : COL_OCUPADO;
    CaracterGrande(NUM_X, NUM_Y, '0' + (libres % 10), NUM_ESCALA, color, COL_PANEL);
}

/* Todo lo que no cambia: fondo, titulo, carril, lineas, panel */
static void DibujarFondo(void)
{
    LCD_Clear(COL_BG);

    /* Titulo */
    Texto(AREA_X + (AREA_W - 7 * FONT_B_W) / 2, 6, "PARQUEO", 2, COL_TEXT, COL_BG);

    /* Marco del parqueo (2 px) */
    Rellenar(AREA_X - 3,      AREA_Y - 3,      AREA_W + 6, 2, COL_FRAME);
    Rellenar(AREA_X - 3,      AREA_Y + AREA_H + 1, AREA_W + 6, 2, COL_FRAME);
    Rellenar(AREA_X - 3,      AREA_Y - 3,      2, AREA_H + 6, COL_FRAME);
    Rellenar(AREA_X + AREA_W + 1, AREA_Y - 3,  2, AREA_H + 6, COL_FRAME);

    /* Carril central con linea punteada */
    Rellenar(AREA_X, LANE_Y, AREA_W, LANE_H, COL_LANE);
    for (int x = AREA_X + 4; x < AREA_X + AREA_W - 10; x += 18)
        Rellenar(x, LANE_Y + LANE_H / 2 - 1, 10, 2, COL_WHITE);

    /* Lineas amarillas divisoras (5 por fila) */
    for (uint8_t k = 0; k <= 4; k++) {
        int lx = AREA_X + k * SLOT_W;
        if (k == 4) lx -= LINE_W;
        Rellenar(lx, ROW1_Y, LINE_W, SLOT_H, COL_LINE);
        Rellenar(lx, ROW2_Y, LINE_W, SLOT_H, COL_LINE);
    }

    /* Etiquetas P1..P8 en el carril */
    char txt[3] = {'P', '1', 0};
    for (uint8_t i = 0; i < NUM_PARQUEOS; i++) {
        txt[1] = '1' + i;
        int lx = SlotX(i) + SLOT_W / 2 + 2;
        int ly = (i < 4) ? (LANE_Y + 6) : (LANE_Y + LANE_H - 18);
        Texto(lx, ly, txt, 1, COL_WHITE, COL_LANE);
    }

    /* Panel de disponibles */
    RectRedondo(PANEL_X, PANEL_Y, PANEL_W, PANEL_H, 10, COL_PANEL_B);
    RectRedondo(PANEL_X + 2, PANEL_Y + 2, PANEL_W - 4, PANEL_H - 4, 9, COL_PANEL);
    Texto(PANEL_X + (PANEL_W - 8 * FONT_S_W) / 2, PANEL_Y + 14, "PARQUEOS", 1, COL_TEXT, COL_PANEL);
    Texto(PANEL_X + (PANEL_W - 7 * FONT_S_W) / 2, PANEL_Y + 30, "LIBRES:", 1, COL_TEXT, COL_PANEL);
    Texto(PANEL_X + (PANEL_W - 4 * FONT_S_W) / 2, NUM_Y + NUM_TAM + 14, "de 8", 1, COL_TEXT, COL_PANEL);
}

/* =========================== Funciones publicas =========================== */
uint8_t GUI_ContarLibres(uint8_t mascara)
{
    uint8_t ocupados = 0;
    for (uint8_t i = 0; i < NUM_PARQUEOS; i++)
        if (mascara & (1u << i)) ocupados++;
    return NUM_PARQUEOS - ocupados;
}

void GUI_Init(void)
{
    DibujarFondo();
    for (uint8_t i = 0; i < NUM_PARQUEOS; i++) {
        DibujarEspacio(i, 0);
        DibujarIndicador(i, 0);
    }
    estadoActual = 0x00;
    libresActual = NUM_PARQUEOS;
    DibujarDisponibles(libresActual);
}

void GUI_Update(uint8_t mascara)
{
    uint8_t cambios = mascara ^ estadoActual;

    for (uint8_t i = 0; i < NUM_PARQUEOS; i++) {
        if (cambios & (1u << i)) {
            uint8_t ocupado = (mascara >> i) & 1u;
            DibujarEspacio(i, ocupado);
            DibujarIndicador(i, ocupado);
        }
    }
    estadoActual = mascara;

    uint8_t libres = GUI_ContarLibres(mascara);
    if (libres != libresActual) {
        DibujarDisponibles(libres);
        libresActual = libres;
    }
}
