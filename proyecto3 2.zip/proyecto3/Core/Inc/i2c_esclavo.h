/**
 ******************************************************************************
 * @file    i2c_esclavo.h
 * @brief   Nucleo como ESCLAVO I2C del ESP32 (modo Listen por interrupciones)
 *          Proyecto 3 - Centro de Control para Parqueo (IE3054)
 ******************************************************************************
 * Protocolo (el ESP32 es el maestro, consulta cada 100 ms):
 *   - Lectura del maestro  (1 byte): la Nucleo responde con su fila
 *                                    bits 0..3 = sus 4 parqueos (1 = ocupado)
 *   - Escritura del maestro (1 byte): estado completo de los 8 parqueos
 *                                    bit0 = P1 ... bit7 = P8 (1 = ocupado)
 * Direcciones (7 bits): Nucleo 1 (pantalla) = 0x20, Nucleo 2 (display) = 0x21
 * Requiere en CubeMX: I2C1 (PB8 SCL / PB9 SDA), 100 kHz, direccion propia,
 *                     I2C1 event interrupt + I2C1 error interrupt activadas.
 ******************************************************************************
 */
#ifndef INC_I2C_ESCLAVO_H_
#define INC_I2C_ESCLAVO_H_

#include "main.h"
#include <stdint.h>

#ifdef HAL_I2C_MODULE_ENABLED

/* direccion: 7 bits (0x20 Nucleo 1, 0x21 Nucleo 2). Se fija aqui aunque en
 * CubeMX haya quedado otra. */
void    I2C_Esclavo_Init(I2C_HandleTypeDef *hi2c, uint8_t direccion);
void    I2C_Esclavo_Tarea(void);                    /* llamar en el while(1)     */
void    I2C_Esclavo_SetFila(uint8_t fila);          /* dato que lee el ESP32     */
uint8_t I2C_Esclavo_Estado(void);                   /* ultimo estado recibido    */
uint8_t I2C_Esclavo_Recibido(void);                 /* 1 si ya llego algun dato  */

#endif /* HAL_I2C_MODULE_ENABLED */

#endif /* INC_I2C_ESCLAVO_H_ */
