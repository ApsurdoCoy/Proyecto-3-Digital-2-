/**
 ******************************************************************************
 * @file    parqueo_gui.h
 * @brief   Interfaz grafica (croquis) del parqueo en la TFT ILI9341
 *          Proyecto 3 - Centro de Control para Parqueo (IE3054)
 ******************************************************************************
 * El estado del parqueo se maneja como una mascara de 8 bits:
 *   bit i = 1 - parqueo P(i+1) ocupado
 *   bit i = 0 - parqueo P(i+1) libre
 * Bits 0..3 = fila superior (P1..P4), bits 4..7 = fila inferior (P5..P8).
 * Esta misma mascara es la que se enviara por I2C al ESP32.
 ******************************************************************************
 */
#ifndef INC_PARQUEO_GUI_H_
#define INC_PARQUEO_GUI_H_

#include <stdint.h>

#define NUM_PARQUEOS  8

/* Dibuja la pantalla completa con todos los parqueos libres */
void GUI_Init(void);

/* Actualiza la pantalla; solo redibuja los parqueos que cambiaron */
void GUI_Update(uint8_t mascaraOcupados);

/* Cantidad de parqueos libres segun la mascara */
uint8_t GUI_ContarLibres(uint8_t mascaraOcupados);

#endif /* INC_PARQUEO_GUI_H_ */
