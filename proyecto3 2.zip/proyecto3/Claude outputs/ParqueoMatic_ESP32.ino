/*************************************************************************************************
  Proyecto 3 - Centro de Control para Parqueo (Parqueo-matic)        IE3054 Electronica Digital 2
  ESP32: maestro I2C + servidor web

  - Lee por I2C el estado de las dos Nucleo (cada una maneja una fila de 4 parqueos).
  - Reenvia a cada Nucleo el estado completo de los 8 parqueos (para la GUI y el display).
  - Publica un servidor web que muestra el parqueo y se actualiza solo (sin recargar) cada
    vez que cambia un espacio, con notificacion de cada cambio.

  Basado en los ejemplos del curso (WebServer en modo STA y en modo AP):
  https://lastminuteengineers.com/creating-esp32-web-server-arduino-ide/
**************************************************************************************************/

//************************************************************************************************
// Librerias
//************************************************************************************************
#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>

//************************************************************************************************
// Configuracion general
//************************************************************************************************
// ---- Modo WiFi ----
// 1 = Access Point: el ESP32 crea su propia red (no depende del WiFi del lugar)
// 0 = Estacion (STA): el ESP32 se conecta a una red existente (p. ej. hotspot del celular)
#define MODO_AP          1

// ---- Simulacion ----
// 1 = no usa I2C; los parqueos se cambian escribiendo 1..8 en el Monitor Serie
//     (sirve para probar la pagina web antes de tener lista la comunicacion I2C)
// 0 = funcionamiento normal con las dos Nucleo
#define SIMULACION       0

// ---- Red en modo AP ----
const char* ap_ssid     = "Parqueo-matic";
const char* ap_password = "12345678";          // minimo 8 caracteres
IPAddress local_ip(192, 168, 1, 1);
IPAddress gateway(192, 168, 1, 1);
IPAddress subnet(255, 255, 255, 0);

// ---- Red en modo STA ----
const char* sta_ssid     = "iPhone122";
const char* sta_password = "qwerty123";

// ---- I2C ----
#define I2C_SDA          21
#define I2C_SCL          22
#define I2C_FREQ         100000                // 100 kHz (Standard Mode, igual que las Nucleo)
#define ADDR_NUCLEO1     0x20                  // Nucleo de la pantalla  -> P1..P4
#define ADDR_NUCLEO2     0x21                  // Nucleo del display     -> P5..P8
#define PERIODO_I2C_MS   100                   // consulta a las Nucleo cada 100 ms

#define NUM_PARQUEOS     8

//************************************************************************************************
// Variables globales
//************************************************************************************************
WebServer server(80);

// Estado del parqueo: bit i = 1 -> P(i+1) ocupado
volatile uint8_t  mascaraOcupados = 0x00;
volatile uint32_t numCambios      = 0;         // aumenta en cada cambio (lo usa la pagina)
bool nucleo1OK = false;                        // la Nucleo respondio en la ultima consulta
bool nucleo2OK = false;

uint32_t tI2C = 0;

//************************************************************************************************
// Prototipos
//************************************************************************************************
void    WiFi_Iniciar(void);
void    I2C_Actualizar(void);
bool    I2C_LeerFila(uint8_t direccion, uint8_t *fila);
bool    I2C_EnviarEstado(uint8_t direccion, uint8_t estado);
void    Simulacion_Leer(void);
void    Estado_Nuevo(uint8_t nueva);
uint8_t ContarLibres(uint8_t mascara);
void    handle_Raiz(void);
void    handle_Estado(void);
void    handle_NotFound(void);

//************************************************************************************************
// Pagina web (HTML + CSS + JavaScript). Se guarda en flash.
// La pagina pide /estado cada 400 ms y solo redibuja cuando el contador de cambios aumenta.
//************************************************************************************************
const char PAGINA_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Parqueo-matic</title>
<style>
  :root { --libre:#2ecc71; --ocupado:#e74c3c; --fondo:#eef1f4; --texto:#1e2329; }
  * { box-sizing:border-box; }
  body { margin:0; font-family:Helvetica, Arial, sans-serif; background:var(--fondo); color:var(--texto); }
  header { background:#1e2329; color:#fff; padding:14px 16px; }
  header h1 { margin:0; font-size:22px; }
  header p  { margin:4px 0 0; font-size:13px; opacity:.75; }
  main { max-width:760px; margin:0 auto; padding:16px; }
  .resumen { display:flex; gap:12px; margin-bottom:16px; }
  .tarjeta { flex:1; background:#fff; border-radius:10px; padding:12px; text-align:center;
             box-shadow:0 1px 3px rgba(0,0,0,.1); }
  .tarjeta .num { font-size:44px; font-weight:bold; }
  .tarjeta .lbl { font-size:13px; color:#666; }
  .lote { background:#555a62; border-radius:10px; padding:10px; }
  .fila { display:grid; grid-template-columns:repeat(4, 1fr); gap:8px; }
  .carril { height:34px; border-top:2px dashed #ddd; border-bottom:2px dashed #ddd; margin:8px 0; }
  .esp { height:110px; border-radius:6px; border-left:4px solid #f5be28; border-right:4px solid #f5be28;
         display:flex; flex-direction:column; align-items:center; justify-content:center;
         color:#fff; font-weight:bold; transition:background .3s; }
  .esp .id { font-size:20px; }
  .esp .st { font-size:12px; margin-top:4px; }
  .libre   { background:var(--libre); }
  .ocupado { background:var(--ocupado); }
  .nucleos { display:flex; gap:12px; font-size:13px; margin:12px 0; }
  .punto { display:inline-block; width:10px; height:10px; border-radius:50%; margin-right:4px; }
  h2 { font-size:16px; margin:18px 0 8px; }
  #log { list-style:none; padding:0; margin:0; background:#fff; border-radius:10px;
         max-height:220px; overflow-y:auto; box-shadow:0 1px 3px rgba(0,0,0,.1); }
  #log li { padding:8px 12px; border-bottom:1px solid #eee; font-size:14px; }
  #toast { position:fixed; left:50%; bottom:20px; transform:translateX(-50%); background:#1e2329;
           color:#fff; padding:12px 18px; border-radius:8px; opacity:0; transition:opacity .3s;
           pointer-events:none; max-width:90%; }
  #toast.ver { opacity:1; }
</style>
</head>
<body>
<header>
  <h1>Parqueo-matic &#128664;</h1>
  <p>Monitoreo en tiempo real &middot; Nivel piloto (8 espacios)</p>
</header>
<main>
  <div class="resumen">
    <div class="tarjeta"><div class="num" id="libres">-</div><div class="lbl">Espacios libres</div></div>
    <div class="tarjeta"><div class="num" id="ocupados">-</div><div class="lbl">Ocupados</div></div>
  </div>

  <div class="lote">
    <div class="fila" id="fila1"></div>
    <div class="carril"></div>
    <div class="fila" id="fila2"></div>
  </div>

  <div class="nucleos">
    <span><span class="punto" id="n1"></span>Nucleo 1 (P1-P4)</span>
    <span><span class="punto" id="n2"></span>Nucleo 2 (P5-P8)</span>
    <span><span class="punto" id="web"></span>Servidor</span>
  </div>

  <h2>Notificaciones</h2>
  <ul id="log"><li>Esperando datos...</li></ul>
</main>
<div id="toast"></div>

<script>
  // ---- Crea los 8 espacios ----
  for (let i = 0; i < 8; i++) {
    const d = document.createElement('div');
    d.className = 'esp libre';
    d.id = 'p' + i;
    d.innerHTML = '<span class="id">P' + (i + 1) + '</span><span class="st">LIBRE</span>';
    document.getElementById(i < 4 ? 'fila1' : 'fila2').appendChild(d);
  }

  let ultimoCambio = -1;   // contador de cambios del ESP32
  let ultimaMascara = null;

  function hora() { return new Date().toLocaleTimeString(); }

  function notificar(texto) {
    const log = document.getElementById('log');
    if (log.firstChild && log.firstChild.textContent === 'Esperando datos...') log.innerHTML = '';
    const li = document.createElement('li');
    li.textContent = hora() + '  -  ' + texto;
    log.insertBefore(li, log.firstChild);
    const t = document.getElementById('toast');
    t.textContent = texto;
    t.classList.add('ver');
    clearTimeout(t.timer);
    t.timer = setTimeout(() => t.classList.remove('ver'), 2500);
  }

  function dibujar(e) {
    for (let i = 0; i < 8; i++) {
      const ocup = (e.ocupados >> i) & 1;
      const d = document.getElementById('p' + i);
      d.className = 'esp ' + (ocup ? 'ocupado' : 'libre');
      d.querySelector('.st').textContent = ocup ? 'OCUPADO' : 'LIBRE';
    }
    document.getElementById('libres').textContent   = e.libres;
    document.getElementById('ocupados').textContent = 8 - e.libres;
    document.getElementById('libres').style.color   = e.libres > 0 ? 'var(--libre)' : 'var(--ocupado)';
    document.getElementById('n1').style.background  = e.n1 ? 'var(--libre)' : 'var(--ocupado)';
    document.getElementById('n2').style.background  = e.n2 ? 'var(--libre)' : 'var(--ocupado)';
  }

  async function consultar() {
    try {
      const r = await fetch('/estado', { cache: 'no-store' });
      const e = await r.json();
      document.getElementById('web').style.background = 'var(--libre)';

      if (e.cambios !== ultimoCambio) {
        if (ultimaMascara !== null) {
          // Notificacion por cada espacio que cambio
          const dif = e.ocupados ^ ultimaMascara;
          for (let i = 0; i < 8; i++) {
            if ((dif >> i) & 1) {
              notificar('P' + (i + 1) + (((e.ocupados >> i) & 1) ? ' ocupado' : ' liberado') +
                        '  (libres: ' + e.libres + ')');
            }
          }
        } else {
          notificar('Conectado. Espacios libres: ' + e.libres);
        }
        ultimoCambio  = e.cambios;
        ultimaMascara = e.ocupados;
        dibujar(e);
      } else {
        dibujar(e);   // actualiza tambien el estado de conexion de las Nucleo
      }
    } catch (err) {
      document.getElementById('web').style.background = 'var(--ocupado)';
    }
    setTimeout(consultar, 400);
  }
  consultar();
</script>
</body>
</html>
)rawliteral";

//************************************************************************************************
// Configuracion
//************************************************************************************************
void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println();
  Serial.println("Parqueo-matic - ESP32 (I2C maestro + Web Server)");

#if !SIMULACION
  Wire.begin(I2C_SDA, I2C_SCL, I2C_FREQ);
  Serial.println("I2C maestro iniciado (SDA=21, SCL=22)");
#else
  Serial.println("MODO SIMULACION: escriba 1..8 en el Monitor Serie para cambiar un parqueo");
#endif

  WiFi_Iniciar();

  server.on("/", handle_Raiz);
  server.on("/estado", handle_Estado);
  server.onNotFound(handle_NotFound);
  server.begin();
  Serial.println("HTTP server started");
}

//************************************************************************************************
// Loop principal
//************************************************************************************************
void loop() {
  server.handleClient();                       // atiende a los navegadores conectados

#if SIMULACION
  Simulacion_Leer();
#else
  if (millis() - tI2C >= PERIODO_I2C_MS) {     // consulta periodica a las Nucleo
    tI2C = millis();
    I2C_Actualizar();
  }
#endif
}

//************************************************************************************************
// WiFi: modo AP o modo estacion
//************************************************************************************************
void WiFi_Iniciar(void) {
#if MODO_AP
  WiFi.mode(WIFI_AP);
  WiFi.softAP(ap_ssid, ap_password);
  WiFi.softAPConfig(local_ip, gateway, subnet);
  delay(100);
  Serial.print("Red WiFi creada: ");
  Serial.println(ap_ssid);
  Serial.print("Pagina web: http://");
  Serial.println(WiFi.softAPIP());
#else
  WiFi.mode(WIFI_STA);
  WiFi.begin(sta_ssid, sta_password);
  Serial.print("Conectando a ");
  Serial.println(sta_ssid);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
  Serial.print("Conectado. Pagina web: http://");
  Serial.println(WiFi.localIP());
#endif
}

//************************************************************************************************
// I2C: lee la fila de cada Nucleo y les envia el estado completo
//   Lectura  (1 byte): bits 0..3 = parqueos de esa fila (1 = ocupado)
//   Escritura(1 byte): mascara completa P1..P8 (bit0 = P1 ... bit7 = P8)
//************************************************************************************************
void I2C_Actualizar(void) {
  uint8_t fila1 = mascaraOcupados & 0x0F;          // si no responde, se conserva lo anterior
  uint8_t fila2 = (mascaraOcupados >> 4) & 0x0F;

  nucleo1OK = I2C_LeerFila(ADDR_NUCLEO1, &fila1);
  nucleo2OK = I2C_LeerFila(ADDR_NUCLEO2, &fila2);

  uint8_t nueva = (fila1 & 0x0F) | ((fila2 & 0x0F) << 4);
  if (nueva != mascaraOcupados) {
    Estado_Nuevo(nueva);
  }

  // Cada Nucleo recibe el estado completo (GUI de la Nucleo 1 / total del display en la Nucleo 2)
  if (nucleo1OK) I2C_EnviarEstado(ADDR_NUCLEO1, mascaraOcupados);
  if (nucleo2OK) I2C_EnviarEstado(ADDR_NUCLEO2, mascaraOcupados);
}

bool I2C_LeerFila(uint8_t direccion, uint8_t *fila) {
  if (Wire.requestFrom((int)direccion, (int)1) != 1) {
    return false;                                  // la Nucleo no respondio
  }
  *fila = Wire.read() & 0x0F;
  return true;
}

bool I2C_EnviarEstado(uint8_t direccion, uint8_t estado) {
  Wire.beginTransmission(direccion);
  Wire.write(estado);
  return Wire.endTransmission() == 0;
}

//************************************************************************************************
// Simulacion por Monitor Serie (SIMULACION = 1)
//************************************************************************************************
void Simulacion_Leer(void) {
  nucleo1OK = true;
  nucleo2OK = true;
  while (Serial.available()) {
    char c = Serial.read();
    if (c >= '1' && c <= '8') {
      Estado_Nuevo(mascaraOcupados ^ (1u << (c - '1')));
    }
  }
}

//************************************************************************************************
// Registro de un cambio de estado
//************************************************************************************************
void Estado_Nuevo(uint8_t nueva) {
  uint8_t dif = nueva ^ mascaraOcupados;
  mascaraOcupados = nueva;
  numCambios++;

  for (uint8_t i = 0; i < NUM_PARQUEOS; i++) {
    if (dif & (1u << i)) {
      Serial.printf("P%u %s  |  Libres: %u\n", i + 1,
                    (nueva & (1u << i)) ? "OCUPADO" : "LIBRE", ContarLibres(nueva));
    }
  }
}

uint8_t ContarLibres(uint8_t mascara) {
  uint8_t libres = 0;
  for (uint8_t i = 0; i < NUM_PARQUEOS; i++)
    if (!(mascara & (1u << i))) libres++;
  return libres;
}

//************************************************************************************************
// Handlers del servidor web
//************************************************************************************************
// Pagina principal
void handle_Raiz(void) {
  server.send_P(200, "text/html", PAGINA_HTML);
}

// Estado en formato JSON (la pagina lo consulta cada 400 ms)
void handle_Estado(void) {
  char json[96];
  snprintf(json, sizeof(json),
           "{\"ocupados\":%u,\"libres\":%u,\"cambios\":%lu,\"n1\":%u,\"n2\":%u}",
           mascaraOcupados, ContarLibres(mascaraOcupados), (unsigned long)numCambios,
           nucleo1OK ? 1 : 0, nucleo2OK ? 1 : 0);
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "application/json", json);
}

void handle_NotFound(void) {
  server.send(404, "text/plain", "Not found");
}
