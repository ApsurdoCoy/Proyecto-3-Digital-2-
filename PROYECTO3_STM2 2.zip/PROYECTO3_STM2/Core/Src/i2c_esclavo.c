/**
 ******************************************************************************
 * @file    i2c_esclavo.c
 * @brief   Nucleo como ESCLAVO I2C del ESP32 (modo Listen por interrupciones)
 *          Proyecto 3 - Centro de Control para Parqueo (IE3054)
 ******************************************************************************
 * Funcionamiento (por interrupciones, no bloquea el programa principal):
 *   1. HAL_I2C_EnableListen_IT(): la Nucleo espera a que el maestro la llame.
 *   2. Cuando el ESP32 envia la direccion de esta Nucleo -> HAL_I2C_AddrCallback
 *        - si el maestro quiere LEER     -> se le transmite txFila (1 byte)
 *        - si el maestro quiere ESCRIBIR -> se recibe 1 byte en rxBuf
 *   3. Al terminar la transferencia se vuelve a escuchar (ListenCplt).
 *
 * RECUPERACION DE ERRORES (el motivo de esta version):
 *   Ante un error de bus (BERR / ARLO / OVR) la HAL deja el estado en LISTEN y
 *   DESPUES de llamar a HAL_I2C_ErrorCallback apaga las interrupciones del I2C.
 *   Por eso rehabilitar la escucha dentro del callback no sirve: la Nucleo
 *   queda sorda para siempre. Aqui el callback solo levanta una bandera y
 *   I2C_Esclavo_Tarea(), llamada desde el while(1), reinicia el periferico.
 *   Ademas hay un "watchdog": si el maestro no nos llama en 1 s, se reinicia.
 ******************************************************************************
 */
#include "i2c_esclavo.h"
#include <stdio.h>

#ifdef HAL_I2C_MODULE_ENABLED

#define I2C_SIN_TRAFICO_MS   1000U   /* el ESP32 consulta cada 100 ms          */

static I2C_HandleTypeDef *hI2C = NULL;
static uint8_t           miDireccion = 0;   /* 7 bits */

static volatile uint8_t  txFila    = 0;   /* fila de esta Nucleo   */
static uint8_t           txBuf     = 0;   /* copia que se transmite                */
static uint8_t           rxBuf     = 0;   /* byte que llega del ESP32              */
static volatile uint8_t  estado    = 0;   /* ultimo estado completo recibido       */
static volatile uint8_t  recibido  = 0;   /* 1 cuando ya llego al menos un dato    */

/* ---- Recuperacion / diagnostico ---- */
static volatile uint8_t  reiniciar        = 0;  /* la ISR pide reiniciar el I2C   */
static volatile uint32_t ultimoError      = 0;  /* ErrorCode de la HAL            */
static volatile uint32_t tUltimaDireccion = 0;  /* tick de la ultima llamada      */
static uint32_t          numReinicios     = 0;

/* ============================ Funciones publicas ========================== */
static void I2C_Reiniciar(void)
{
    /* DeInit + Init hace un reset completo del periferico (SWRST) y suelta
     * SDA/SCL si el esclavo se habia quedado a mitad de un byte.             */
    HAL_I2C_DeInit(hI2C);
    hI2C->ErrorCode = HAL_I2C_ERROR_NONE;
    hI2C->Init.OwnAddress1 = (uint32_t)miDireccion << 1;
    HAL_I2C_Init(hI2C);
    HAL_I2C_EnableListen_IT(hI2C);
    tUltimaDireccion = HAL_GetTick();
}

void I2C_Esclavo_Init(I2C_HandleTypeDef *hi2c, uint8_t direccion)
{
    hI2C = hi2c;
    miDireccion = direccion;
    I2C_Reiniciar();             /* fija la direccion (0x20 - 0x40) y escucha */
}

/* Llamar en cada vuelta del while(1) */
void I2C_Esclavo_Tarea(void)
{
    if (hI2C == NULL) return;

    if (!reiniciar && (HAL_GetTick() - tUltimaDireccion) > I2C_SIN_TRAFICO_MS)
        reiniciar = 1;

    if (reiniciar) {
        reiniciar = 0;
        numReinicios++;
        printf("I2C reiniciado #%lu (ErrorCode=0x%lX: 1=BERR 2=ARLO 4=AF 8=OVR)\r\n",
               (unsigned long)numReinicios, (unsigned long)ultimoError);
        I2C_Reiniciar();
    }
}

void I2C_Esclavo_SetFila(uint8_t fila)
{
    txFila = fila & 0x0F;
}

uint8_t I2C_Esclavo_Estado(void)
{
    return estado;
}

uint8_t I2C_Esclavo_Recibido(void)
{
    return recibido;
}

/* ========================= Callbacks de la HAL ============================ */
/* El maestro envio nuestra direccion */
void HAL_I2C_AddrCallback(I2C_HandleTypeDef *hi2c, uint8_t TransferDirection,
                          uint16_t AddrMatchCode)
{
    (void)AddrMatchCode;
    if (hi2c != hI2C) return;

    tUltimaDireccion = HAL_GetTick();

    if (TransferDirection == I2C_DIRECTION_TRANSMIT) {
        /* El maestro ESCRIBE - recibimos el estado completo */
        HAL_I2C_Slave_Seq_Receive_IT(hi2c, &rxBuf, 1, I2C_FIRST_AND_LAST_FRAME);
    } else {
        /* El maestro LEE - enviamos nuestra fila */
        txBuf = txFila;
        HAL_I2C_Slave_Seq_Transmit_IT(hi2c, &txBuf, 1, I2C_FIRST_AND_LAST_FRAME);
    }
}

/* Llego el byte del maestro */
void HAL_I2C_SlaveRxCpltCallback(I2C_HandleTypeDef *hi2c)
{
    if (hi2c != hI2C) return;
    estado   = rxBuf;
    recibido = 1;
}

/* Termino la transaccion: volver a escuchar */
void HAL_I2C_ListenCpltCallback(I2C_HandleTypeDef *hi2c)
{
    if (hi2c != hI2C) return;
    hi2c->ErrorCode = HAL_I2C_ERROR_NONE;        /* no acumular errores viejos */
    if (HAL_I2C_EnableListen_IT(hi2c) != HAL_OK)
        reiniciar = 1;
}

/* Error de bus. NO se rehabilita aqui (la HAL apaga las IRQ despues de este
 * callback); solo se avisa al programa principal.                            */
void HAL_I2C_ErrorCallback(I2C_HandleTypeDef *hi2c)
{
    if (hi2c != hI2C) return;
    ultimoError = hi2c->ErrorCode;
    /* Un NACK solo (AF) lo recupera la HAL por si misma via ListenCplt */
    if (ultimoError & (HAL_I2C_ERROR_BERR | HAL_I2C_ERROR_ARLO | HAL_I2C_ERROR_OVR))
        reiniciar = 1;
}

#endif /* HAL_I2C_MODULE_ENABLED */
